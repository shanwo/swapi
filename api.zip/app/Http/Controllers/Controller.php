<?php
/**
 * User: Powerless
 * Date: 2021/6/3
 * Blog: https://wzxaini9.cn
 */

namespace App\Http\Controllers;

use App\Services\Service;
use GuzzleHttp\Client;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Log;
use Overtrue\Socialite\SocialiteManager;
use Ramsey\Uuid\Uuid;

class Controller extends BaseController
{
    use ValidatesRequests;

    protected $client;
    protected $request;
    protected $service;
    protected $code = 100;
    protected $msg = null;
    protected $levels = [
        100 => 'debug',
        200 => 'info',
        300 => 'notice',
        400 => 'notice',
    ];

    public function __construct($request)
    {
        $this->request = $request;
        $this->client = new Client();
        $this->service = new Service();
    }

    /**
     * 验证器
     * @param array $rules
     * @param array $customAttributes
     * @param array $messages
     */
    public function validate(array $rules, array $customAttributes = [], array $messages = [])
    {
        $this->code = 400;
        $validator = $this->getValidationFactory()->make($this->request->all(), $rules, $messages, $customAttributes);
        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            $this->msg = current($errors);
        }
    }

    /**
     * 需要返回的数据
     * @param object $data
     * @return \Illuminate\Http\JsonResponse
     */
    public function returnApi($data = [])
    {
        $result = [
            'request' => $this->request->all(),
            'data'    => (object)$data,
            'code'    => (int)$this->code,
            'msg'     => $this->msg,
            'uuid'    => Uuid::uuid6(),
        ];
        Log::log($this->levels[$this->code], 'Return Api', $result);
        \Illuminate\Support\Facades\DB::disconnect('mysql');
        unset($result['request']);
        return response()->json($result);
    }

    /**
     * 功能：对字符串进行加密处理
     * @param string $str
     * 需要加密的内容.
     * @param string $key
     * 加密字符串
     * @return string
     * 加密后的内容
     */
    public function passportEncrypt($str, $key)
    {
        $encrypt_key = md5(rand(0, 32000));
        $ctr = 0;
        $tmp = '';
        for ($i = 0; $i < strlen($str); $i++) {
            $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;
            $tmp .= $encrypt_key[$ctr] . ($str[$i] ^ $encrypt_key[$ctr++]);
        }
        return base64_encode($this->passportKey($tmp, $key));
    }

    /**
     * 功能：对字符串进行解密处理
     * @param string $str
     * 需要解密的密文.
     * @param string $key
     * 加密字符串
     * @return string
     * 解出的内容
     */
    public function passportDecrypt($str, $key)
    {
        $str = $this->passportKey(base64_decode($str), $key);
        $tmp = '';
        for ($i = 0; $i < strlen($str); $i++) {
            $md5 = $str[$i];
            $tmp .= $str[++$i] ^ $md5;
        }
        return $tmp;
    }

    /**
     * 辅助函数
     * @param $str
     * @param $encrypt_key
     * @return string
     */
    private function passportKey($str, $encrypt_key)
    {
        $encrypt_key = md5($encrypt_key);
        $ctr = 0;
        $tmp = '';
        for ($i = 0; $i < strlen($str); $i++) {
            $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;
            $tmp .= $str[$i] ^ $encrypt_key[$ctr++];
        }
        return $tmp;
    }

    protected function driver($request, $name)
    {
        $config = $this->service->configInfo($name);
        //公众号数据，使用微信驱动
        if($name == 'official'){
            $socialite = new SocialiteManager([
                'wechat' => [
                    'client_id'     => $config['app_id'],
                    'client_secret' => $config['secret'],
                    'redirect'      => $config['callback'],
                ],
            ], $request);
            return $socialite->driver('wechat')->scopes(['snsapi_userinfo']);
        }else{
            $socialite = new SocialiteManager([
                $name => [
                    'client_id'     => $config['key'],
                    'client_secret' => $config['secret'],
                    'redirect'      => $config['callback'],
                ],
            ], $request);
            return $socialite->driver($name);
        }
    }
}
